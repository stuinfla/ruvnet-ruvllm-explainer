# ruvllm Drop-in

One zip. Two halves: a for-humans primer and a for-ai searchable knowledge base.

## What's inside

```
ruvllm-dropin/
  for-humans/   — read first
    ruvllm-primer.md         — top-down orientation: what it is, why, how it works
  for-ai/       — the searchable knowledge pack (wire this into your agent)
    ruvllm-kb.rvf            — single 384-dim vector DB (the "brain")
    ruvllm-kb.passages.jsonl — full passage text (274 passages; search returns TEXT, not {id,distance})
    ruvllm-kb.ids.json       — id → passage index
    ruvllm-symbols.json      — exact public API: every symbol + signature + doc + location
    ruvllm-dep-graph.json    — component dependency graph (what depends on what)
    ruvllm-entrypoints.json  — build/test/run commands + binaries
    ask-kb.mjs · kb-mcp-server.mjs · kb.config.mjs · resolve-deps.mjs · package.json
  README.md     — this file
  manifest.json — build metadata
```

## Three steps to wire the AI half in
```bash
# 1 — unzip + install (two deps, Node 18+)
unzip ruvllm-knowledge-pack.zip && cd ruvllm-dropin/for-ai && npm install

# 2 — ask the brain a question straight away
node ask-kb.mjs ruvllm "what does ruvllm actually do"

# 3 — point your AI host at it with a .mcp.json in your project root:
#   { "mcpServers": { "ruvllm-kb": { "command": "node", "args": ["for-ai/kb-mcp-server.mjs"] } } }
```

Built with the Repo-Primer recipe (ADR-0001 / ADR-0005). Embedder: Xenova/bge-small-en-v1.5.
