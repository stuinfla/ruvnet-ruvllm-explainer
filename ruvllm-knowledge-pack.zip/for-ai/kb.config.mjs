// kb.config.mjs — the one store in this pack.
export const targets = { "ruvllm": {
  "slug": "ruvllm",
  "metaName": "RuVLLM",
  "embed": {
    "model": "Xenova/bge-small-en-v1.5",
    "dim": 384,
    "pooling": "mean",
    "queryPrefix": "Represent this sentence for searching relevant passages: ",
    "rankScale": 0.6,
    "rvfSuffix": ".rvf"
  },
  "productNames": [
    "RuVLLM",
    "coding-4b",
    "coding-4b-r2",
    "@ruvector/ruvllm-gpu-loop",
    "GPU loop",
    "LoRA adapter",
    "Direct weight edit",
    "McNemar",
    "RVF",
    "Ruflo",
    "MCP"
  ],
  "scopeExclude": [
    "node_modules",
    "dist",
    "target",
    ".git",
    "coverage",
    "pkg",
    ".next"
  ],
  "codeExt": [
    ".ts",
    ".js",
    ".mjs",
    ".rs",
    ".py",
    ".json",
    ".md"
  ],
  "componentRoots": [
    "docs",
    "experiments",
    "integrations"
  ],
  "componentWord": [
    "crate",
    "package",
    "module",
    "component"
  ],
  "include": [
    {
      "rule": "mdSweepFullText",
      "roots": [
        "."
      ]
    },
    {
      "rule": "literalFiles",
      "files": [
        "README.md",
        "package.json",
        "experiments/model-improvement/STATUS.json",
        "docs/adr/ADR-016-paired-model-improvement-measurement.md",
        "docs/adr/ADR-017-vast-host-adapter-and-live-paired-run.md",
        "integrations/metaharness/GPU-LOOP.md"
      ]
    },
    {
      "rule": "sourceBodies",
      "roots": [
        "integrations",
        "experiments"
      ],
      "ext": [
        ".ts",
        ".js",
        ".mjs",
        ".rs",
        ".py"
      ]
    }
  ]
} };
export const defaultTarget = "ruvllm";
export function getTarget(slug = defaultTarget) {
  const t = targets[slug];
  if (!t) throw new Error(`unknown store "${slug}" — this pack holds only "${defaultTarget}"`);
  return t;
}
export default { targets, defaultTarget, getTarget };
