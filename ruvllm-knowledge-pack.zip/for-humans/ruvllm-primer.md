## 1. What is ruvllm

RuVLLM's tagline is "Change a model. Prove it. Keep the original." It trains and edits small adapters for open language models, then measures each one against the unchanged base model. Both run on the same tasks, under a keep/reject rule written before any results exist. The original weights restore byte for byte.

The repo mixes npm and Python, with a Rust native engine (`native/`, built with cargo). It is indexed as 2 components and 510 public symbols.

## 2. What can it do for you

- **Make a small, checked change to an open model.** Two routes are included:
  - A LoRA adapter. The included `coding-4b` is 1.5M parameters for Qwen3.5 4B, in PEFT and MLX formats.
  - A policy-bounded direct weight edit, done by a Rust editor on a copy of the model.
- **Decide keep or reject on evidence.** Base and candidate answer identical tasks on the same GPU. The comparison is a paired exact McNemar test, not two averages. Every raw answer is kept, and a local re-score is run.
- **Spot regressions.** Results are broken down by tool family and by case. In the README's held-out run, `coding-4b-r2` fixed every tool failure but lost 16 arithmetic answers. The rule frozen before training says capability anchors must not regress, so it was rejected.
- **Rent GPUs with caps.** The README lists four limits: an admission budget, a worst-case offer price, an accrued-cost ceiling, and an independent destroy timer. Jobs are restart-safe and only count as complete when the local re-score matches.
- **Reproduce the published numbers.** The README reports `coding-4b` going from 123 to 173 of 192 tool passes with 0 regressions (p = 1.8e-15). On a held-out panel it went from 149 to 176 of 192. GPU cost per paired evaluation was $0.27–$0.91. These are the project's own reported figures.

## 3. What is it made of (the components)

| Component | Ecosystem | Role |
| :--- | :--- | :--- |
| `@ruvector/ruvllm-gpu-loop` | npm | The GPU job loop and CLI, published on npm. It can be driven from the CLI, Claude Code `/loop`, or any MCP host. |
| `ruflo-code-model` | python | Model-side code. The data-provenance doc references `ruflo_model/data.py`, which generates 288 training and 36 validation examples from original templates. They cover Read, Edit, Write, Glob, Grep and Bash tool schemas. |

Beyond the two components:
- `native/` holds the Rust weight-evolution engine (the `ruvllm-weight-evolution` crate and `weight_evolution` binary).
- `experiments/model-improvement/` holds the paired-measurement protocol and results.
- `benchmarks/` holds saved evidence and its verifier.
- `integrations/metaharness/` holds the MetaHarness integration, including the GPU loop guide.

External dependencies are `@metaharness/darwin`, `@metaharness/flywheel`, `@metaharness/weight-eft`, `httpx`, `jsonschema` and `pyyaml`. No internal dependencies are listed.

## 4. How it works

The README describes a four-step lifecycle:

1. **Freeze.** Pin the model revision, task panel, generation settings and keep rule. Tasks and expected answers go into a SHA-256-pinned bundle before any model output exists. The panel is 256 cases: 8 tool families × 24, plus arithmetic as a retained-capability anchor. `experiments/model-improvement/prepare.py` creates the bundle.
2. **Change a copy.** Train a LoRA adapter or apply a bounded weight edit. The original file is never modified.
3. **Measure in pairs.** Run base and candidate on identical tasks and keep every raw answer. Score with the frozen scorer.
4. **Decide and restore.** Apply the preregistered rule, then verify that the original restores byte for byte (matching source and restored hashes).

Deployment needs separate approval. The measurement protocol is written up in ADR 016, and the Vast.ai host adapter in ADR 017.

## 5. How do I install and use it

The brief gives no install command or quickstart. The npm package is `@ruvector/ruvllm-gpu-loop`, and the README has a "Quick start" section that was not included here.

Commands found in the repo:

```sh
# npm
npm run test
npm run bench
npm run guard:name        # also: prepack, postpack, prepublishOnly

# repository / evidence checks (Python 3.11+, standard library only for the benchmark verifier)
python3 scripts/check_repository.py
python3 scripts/verify_benchmarks.py
python3 -B -m unittest discover -s benchmarks/tests -v

# native Rust engine
cargo test --locked -p ruvllm-weight-evolution --lib
cargo build --locked --release --bin weight_evolution
```

There are also `python3 verify_source.py` and `python3 smoke.py`, and the venv step is `python3 -m venv .venv`. The contributing guide says to run `check_repository.py` and `verify_benchmarks.py` first. Run the native tests from `native/` so Rust uses the pinned toolchain.

To verify the saved benchmark evidence, no GPU, network, model download or credential is needed. `verify_benchmarks.py` should report `verified: true` and `generations_verified: 462`.

A live paired run needs a CUDA host. The measurement doc pins `torch==2.11.0`, `transformers==5.12.1`, `peft==0.21.2` and `safetensors==0.7.0`.

## 6. Honest scope and limits

- **Narrow evidence.** The headline results are for one base model (Qwen3.5 4B, BF16) and one panel of 192 tool tasks plus 64 arithmetic tasks. They show the adapter improves answers on that panel. They do not generalize beyond it.
- **No big claims.** The repo's own docs say the evidence does not establish state of the art, recursive self-improvement, safety qualification or production authorization.
- **Integrity has limits.** File hashes and self-consistency do not prove remote hardware identity. They also do not protect against replacement of the whole unsigned repo and manifest. Get the commit or manifest SHA256 through an independent trusted channel.
- **Not everything is re-run.** The verifier reports `generated_code_reexecuted: false`. Math text is independently re-scored.
- **Timing figures are observations.** Token and timing numbers describe the recorded runs, not production cost or latency forecasts. The 4B and 0.8B results use different setups and should not be ranked against each other.
- **The orchestration benchmark is tiny.** The MetaHarness CPU benchmark uses an 88-byte synthetic checkpoint. Reusing the Node process cut median time by 51.94% on that sample. The docs say it establishes no accuracy gain, GPU throughput, large-checkpoint speedup or model-inference result.
- **Environment-specific acceptance.** The MetaHarness acceptance evidence is dated 2026-11-03 and covers one Linux x86-64 workspace. Hosted CI and installed-client acceptance are listed as separate.
